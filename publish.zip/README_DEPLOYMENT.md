# Gram Panchayat Portal - Deployment Guide

## 📦 Publish Folder Contents

This folder contains the built production files ready for deployment.

### Files Structure:
- `index.html` - Main HTML file
- `assets/` - CSS, JavaScript, and other static assets
- `index.js` - Backend Node.js server (if deploying full-stack)
- `package.json` - Dependencies list
- `.htaccess` - Apache configuration for SPA routing

## 🚀 Deployment Instructions for cPanel

### Option 1: Frontend Only (Static Files)

1. **Upload to public_html:**
   - Login to cPanel File Manager
   - Navigate to `public_html` or `www` folder
   - Upload all files from this publish folder
   - Make sure `.htaccess` is uploaded (enable "Show Hidden Files")

2. **Set Permissions:**
   - Files: 644
   - Folders: 755

### Option 2: Full-Stack with Node.js

**Note:** This application requires Node.js backend. cPanel shared hosting typically doesn't support Node.js applications. You'll need:

1. **VPS/Dedicated Server** with Node.js support, OR
2. **cPanel with Node.js Selector** feature, OR
3. **Deploy backend separately** to services like:
   - Railway.app
   - Render.com
   - Heroku
   - DigitalOcean App Platform

### For Node.js Deployment:

1. **Upload files to server:**
   ```bash
   # Upload via FTP/SFTP or cPanel File Manager
   ```

2. **Install dependencies:**
   ```bash
   npm install --production
   ```

3. **Set environment variables:**
   Create `.env` file with:
   ```
   DATABASE_URL=your_database_url
   SESSION_SECRET=your_secret_key
   PORT=5000
   NODE_ENV=production
   ```

4. **Start the server:**
   ```bash
   npm start
   ```

5. **Setup Process Manager (PM2):**
   ```bash
   npm install -g pm2
   pm2 start dist/index.js --name gram-panchayat
   pm2 save
   pm2 startup
   ```

## 🔧 Environment Variables Required

- `DATABASE_URL` - PostgreSQL database connection string
- `SESSION_SECRET` - Secret key for session encryption
- `PORT` - Server port (default: 5000)
- `NODE_ENV` - Set to "production"

## 📝 Important Notes

1. **Database:** This app requires PostgreSQL database. Set up database before deployment.
2. **Static Files:** Frontend files are in root, backend is `index.js`
3. **API Endpoints:** Backend serves API at `/api/*` routes
4. **Session Storage:** Currently uses memory store - consider Redis for production

## 🌐 Recommended Hosting Platforms

For full-stack deployment:
- **Railway** (easiest, free tier available)
- **Render** (free tier with PostgreSQL)
- **Vercel** (frontend) + **Railway** (backend)
- **Netlify** (frontend) + **Railway** (backend)
- **DigitalOcean App Platform**

## 📞 Support

If you need help with deployment, check the main project documentation or contact support.
